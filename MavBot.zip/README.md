# MavBot
Bot for the video game StarCraft 2.
It compete in sc2ai.net artificial intelligence tournaments
