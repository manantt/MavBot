from sc2.units import Units
from sc2.constants import *
from sc2.cache import property_cache_forever, property_cache_once_per_frame
from sc2.position import Point2, Point3

import random

class StrategyManager:
	def __init__(self, game):
		self.game = game

		# ingame vars
		self.initialized = False
		self.cloack_units_detected = False
		self.under_attack = False # to do

		# enemy/map/race depending vars
		self.build_cannons = False
		self.build_ramp1_cannon = False # to do
		self.build_ramp2_cannon = False # to do
		self.build_wall = False # to do
		self.observer_rush = False # to do
		self.ground_defenses_list = [2, 0, 0, 0] # to do
		self.cannon_rush = False # in progress
		self.worker_rush = False # to do
		self.oracle_harass = False # to do
		self.adept_harass = False # to do
		self.phoenix_harass = False # to do
		self.allucination_bait = False # to do

		# cannon rush vars
		self.cannon_rush_workers = []
		self.cannon_rush_pylon_position = Point2()
		self.ladder_maps_cannon_rush_position = {
			#"AcropolisLE.SC2Map": [Point2((100, 100)),Point2((200,200))],
			#"AcropolisLE.SC2Map": [Point2((100, 100)),Point2((200,200))],
			#"DiscoBloodbathLE.SC2Map": [Point2((100, 100)),Point2((200,200))],
			#"EphemeronLE.SC2Map": [Point2((100, 100)),Point2((200,200))],
			#"ThunderbirdLE.SC2Map": [Point2((100, 100)),Point2((200,200))],
			"ThunderbirdLE.SC2Map": [Point2((31, 110)),Point2((164,53))],
			#"TritonLE.SC2Map": [Point2((100, 100)),Point2((200,200))],
			#"WintersGateLE.SC2Map": [Point2((100, 100)),Point2((200,200))],
			#"WorldofSleepersLE.SC2Map": [Point2((100, 100)),Point2((200,200))]
		}

		"""self.game_steps = [
			0, # early
			1, # 2nd nexus construction started
			2, # 1st attack group created
		]
		self.objetive_proves = [20, 64, 64]
		self.objetive_zealots = [4, 4, 4]
		self.objetive_observers = [0, 1, 2]
		self.objetive_voidrays = [31, 31, 31]"""

	def prepare_strat(self):
		if not self.initialized:
			self.initialized = True
			# cannon rush
			actual_map = self.game.game_info.local_map_path
			if actual_map in self.ladder_maps_cannon_rush_position:
				self.cannon_rush_pylon_position = self.game.enemy_start_locations[0].closest(self.ladder_maps_cannon_rush_position[actual_map])
			else:
				self.cannon_rush = False

	async def do_strat(self):
		self.prepare_strat()
		await self.do_cannon_rush()
		self.check_cloacked()	

	def doing_strat(self):
		""" Returns true if an actual strategy should override general bot decision making """
		if self.cannon_rush:
			return True
		return False

	async def do_cannon_rush(self):
		#for u in self.game.structures(PYLON):
		#	print(u.position)
		if self.cannon_rush:
			if not self.cannon_rush_workers:
				self.cannon_rush_workers.append(self.game.units(PROBE).random.tag)
			for worker in self.game.units().tags_in(self.cannon_rush_workers):
				# train probes
				self.game.train_manager.train_probe()
				# move to position
				if worker.distance_to(self.cannon_rush_pylon_position) > 2:
					self.game.combined_actions.append(worker.move(self.cannon_rush_pylon_position))
				# place first pylon
				if not self.game.structures(PYLON).amount and self.game.can_afford(PYLON) and not self.game.already_pending(PYLON):
					await self.game.build(PYLON, near=self.game.townhalls().first.position.towards(self.game.game_info.map_center, 7))
				# build forge
				if self.game.structures(PYLON).ready.amount and self.game.can_afford(FORGE) and not self.game.structures(FORGE).amount and not self.game.already_pending(FORGE):
					await self.game.build(FORGE, near=self.game.structures(PYLON).ready.random.position.towards(self.game.game_info.map_center, 4))
				# build cheese pylon
				if self.game.structures(FORGE).amount and self.game.can_afford(PYLON) and not self.game.structures(PYLON).closer_than(1, self.cannon_rush_pylon_position).amount and not self.game.already_pending(PYLON):
					await self.game.build(PYLON, near=self.cannon_rush_pylon_position, build_worker=worker)
					print("aaaaa")
				# build cannons
				if self.game.structures(PYLON).amount and self.game.structures(PYLON).closer_than(1, self.cannon_rush_pylon_position).amount and (not self.game.structures(PHOTONCANNON).amount or self.game.structures(PHOTONCANNON).closer_than(1, self.cannon_rush_pylon_position).amount < 3):
					pylon = self.game.structures(PYLON).closer_than(1, self.cannon_rush_pylon_position).first
					await self.game.build(PHOTONCANNON, near=pylon.position)
				# end
				if self.game.structures(PHOTONCANNON).amount and self.game.structures(PHOTONCANNON).closer_than(20, self.cannon_rush_pylon_position).amount >= 3:
					self.cannon_rush = False

	def check_cloacked(self):
		if not self.cloack_units_detected and self.game.enemy_units.filter(lambda unit: unit.is_cloaked).amount:
			self.cloack_units_detected = True

	@property
	def ground_defenses(self):
		return {
			ZEALOT: self.ground_defenses_array[0],
			STALKER:  self.ground_defenses_array[1],
			SENTRY:  self.ground_defenses_array[2],
			IMMORTAL:  self.ground_defenses_array[3],
		}