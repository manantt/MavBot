# How early train observers
OBSERVER_RUSH = 0
OBSERVER_NORMAL = 1
OBSERVER_LATE = 2

